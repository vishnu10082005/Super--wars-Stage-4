const PLAYERS = [
  'Spiderman',
  'Captain America',
  'Wonderwoman',
  // Add more players if needed
];

class Player {
  constructor(id, name, type) {
    this.id = id;
    this.name = name;
    this.strength = this.getRandomStrength();
    this.image = 'images/super-1.png'; 
    this.type = type;
  }

  getRandomStrength() {
    return Math.ceil(Math.random() * 100);
  }

  view() {
    const playerDiv = document.createElement('div');
    playerDiv.classList.add('player');
    playerDiv.setAttribute('data-id', this.id);

    const image = document.createElement('img');
    image.setAttribute('src', this.image);

    const playerName = document.createElement('div');
    playerName.textContent = this.name;

    const strengthDiv = document.createElement('div');
    strengthDiv.textContent = this.strength;
    strengthDiv.classList.add('strength'); // Add the 'strength' class

    playerDiv.append(image, playerName, strengthDiv);
    return playerDiv;
  }
}

class Superwar {
  constructor(players) {
    this.players = players.map((name, index) => {
      const type = index % 2 === 0 ? 'hero' : 'villain';
      return new Player(index, name, type);
    });
  }

  viewPlayers() {
    let team = document.getElementById('heroes');
    team.innerHTML = '';
    let fragment = this.buildPlayers('hero');
    team.append(fragment);

    team = document.getElementById('villains');
    team.innerHTML = '';
    fragment = this.buildPlayers('villain');
    team.append(fragment);
  }

  buildPlayers(type) {
    const fragment = document.createDocumentFragment();
    this.players
      .filter((player) => player.type === type)
      .forEach((player) => fragment.append(player.view()));
    return fragment;
  }
}

window.onload = () => {
  const superwar = new Superwar(PLAYERS);
  superwar.viewPlayers();
};
